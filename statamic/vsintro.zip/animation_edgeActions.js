/***********************
* Adobe Edge Animate Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge Animate
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

   //Edge symbol: 'stage'
   (function(symbolName) {
      
      
   })("stage");
   //Edge symbol end:'stage'

   //=========================================================
   
   //Edge symbol: 'we-are-vs-and-we'
   (function(symbolName) {   
   
   })("we-are-vs-and-we");
   //Edge symbol end:'we-are-vs-and-we'

   //=========================================================
   
   //Edge symbol: 'mask-build-listen'
   (function(symbolName) {   
   
   })("mask-build-listen");
   //Edge symbol end:'mask-build-listen'

   //=========================================================
   
   //Edge symbol: 'mask-to-make-your'
   (function(symbolName) {   
   
   })("mask-to-make-your");
   //Edge symbol end:'mask-to-make-your'

   //=========================================================
   
   //Edge symbol: 'step-1'
   (function(symbolName) {   
   
   })("step-1");
   //Edge symbol end:'step-1'

})(jQuery, AdobeEdge, "EDGE-6766476");